import numpy as np
from numba import jit
import matplotlib.pyplot as plt
import simulation_cpu  as sim
from matplotlib.animation import FuncAnimation
import analyze_tool as an



lamda = 8e-7 
time_cycal= lamda/sim.c
pulse_width = 4*time_cycal 
power_in = 3e5
fea = np.pi/2




sigma = 1000
eps_r = 6
alpha = 0
ms0= np.array([0, 0 , 1])*1e4



eps_r_comp = eps_r - 1j * sigma *lamda * sim.miu * sim.c /(2*np.pi)
n = eps_r_comp ** 0.5




time_cut = 100
dt = time_cycal/time_cut
dz = 2*sim.c *dt


# spaece and time defntion
z1 = int(5*pulse_width/dt) +3




# pulse_width = 4*time_cycal
ms0 = [0, 0, 1]
alpha =0.0001

close_system = False

pulse_width_vec = np.linspace(20, 21 , 1) * time_cycal


exit_steps = time_cut




theoretical_reflectivity = (abs(( 1- n) /(1 + n))) ** 2
theoretical_transmision = 1 - theoretical_reflectivity
theoretical_penetration_depth_e = -1/ (2* np.pi/ lamda * np.imag(n))  # power of the field decays to 1/e of its surface value.
theoretical_penetration_depth_p = 0.5 * theoretical_penetration_depth_e   # power decays to 1/e of its surface value.


S_comp = np.zeros(np.size(pulse_width_vec))
transmition_vec = np.zeros(np.size(pulse_width_vec))
return_vec = np.zeros(np.size(pulse_width_vec))
penetration_vec = np.zeros(np.size(pulse_width_vec))
ind_to_seve = int(3*theoretical_penetration_depth_p//dz)

save_time =[]

for i, width in enumerate(pulse_width_vec):


    len_matiral_i = int(4*width/dt/abs(n))*dz

    z1_i = int(3*width/dt) +3
    z2_i = z1_i + int(len_matiral_i/dz) 
    lenz_i= z2_i + time_cut//2


    pik_enter_step_i = 4*int(width/dt)
    void_steps_i = 2*z1_i
    matiral_steps_i = int(2* abs(n)* (z2_i - z1_i))


    simulation_time_i = 2*(pik_enter_step_i + void_steps_i + matiral_steps_i + exit_steps)


    t1_i = pik_enter_step_i + void_steps_i
    t2_i = t1_i + void_steps_i
    t3_i = t2_i + 2*matiral_steps_i
    t2_5_i = (t2_i + t3_i)//2

    
    save_location_i = np.arange(z1_i- 1 ,z1_i+ ind_to_seve)
    save_location_i[0] = 4
    save_location_i[-1] = lenz_i- 6
    save_location_i.astype(int)


    time_res, spece_res = sim.simulation(z1_i, z2_i, eps_r , sigma, alpha, ms0,
        power_in , fea , width,
        save_location_i, save_time, False,
        dt, simulation_time_i, lamda )

    E_real= sim.heta*spece_res[1]
    H = spece_res[0]
    S = np.cross(np.real(E_real),np.real(H))
    
    S_in_enter_point = S[:,0,2]
    S_in_z1 = S[:,1,2]
    S_in_out = S[:,-1,2] 

    S_send_to_void = sum(S_in_enter_point[:t1_i])*dt
    S_first_return_to_void = sum(S_in_enter_point[t1_i:t2_5_i])*dt
    S_first_enter_to_matirial = sum(S_in_z1[:t2_i])*dt

    S_depletion = S[:,1:-1,2]
    P_depletion = np.sum(S_depletion,0)* dt
    target = max(P_depletion)/np.e
    closest_index = np.argmin(np.abs(P_depletion - target)) 


    penetration_vec[i] = closest_index * dz
    S_comp[i] = S_send_to_void
    transmition_vec[i] = S_first_enter_to_matirial/ S_send_to_void
    return_vec[i] = S_first_return_to_void/ S_send_to_void

check5_power_in=( (power_in - S_comp)/power_in)
